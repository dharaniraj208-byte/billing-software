export type PaymentMethod = 'Cash' | 'UPI' | 'Card' | 'Credit / Due'
export type Product = { id: string; name: string; sku: string; category: string; purchasePrice: number; sellingPrice: number; stock: number; minimumStock: number; unit: string; image?: string }
export type Customer = { id: string; name: string; mobile: string; address: string; totalPurchases: number; due: number }
export type BillItem = { productId: string; name: string; sku: string; quantity: number; price: number; discount: number; discountScope?: 'line' | 'per-unit' }
export type Bill = { id: string; invoiceNumber: string; date: string; customerId?: string; customerName: string; customerMobile: string; items: BillItem[]; subtotal: number; discount: number; total: number; paymentMethod: PaymentMethod; amountReceived: number; change: number }
export type ReceiptPaperSize = '58mm' | '80mm'
export type Shop = { shopName: string; ownerName: string; mobile: string; email: string; address: string; logo?: string; invoicePrefix: string; nextInvoiceNumber: number; defaultDiscount: number; currency: string; receiptPaperSize: ReceiptPaperSize; autoPrintReceipt: boolean; lowStockAlert: boolean; allowNegativeStock: boolean }
export type Store = { setupCompleted: boolean; shop: Shop; products: Product[]; customers: Customer[]; bills: Bill[]; updatedAt: number }

export const emptyShop: Shop = { shopName: '', ownerName: '', mobile: '', email: '', address: '', logo: '', invoicePrefix: 'INV-', nextInvoiceNumber: 1001, defaultDiscount: 0, currency: 'INR', receiptPaperSize: '80mm', autoPrintReceipt: false, lowStockAlert: true, allowNegativeStock: false }

export const starterProducts: Product[] = [
  { id: 'p-rice', name: 'Premium Rice 5kg', sku: 'RICE-5', category: 'Groceries', purchasePrice: 410, sellingPrice: 500, stock: 20, minimumStock: 5, unit: 'bag' },
  { id: 'p-oil', name: 'Sunflower Oil 1L', sku: 'OIL-1', category: 'Groceries', purchasePrice: 108, sellingPrice: 135, stock: 4, minimumStock: 5, unit: 'bottle' },
  { id: 'p-tea', name: 'Classic Tea 500g', sku: 'TEA-500', category: 'Beverages', purchasePrice: 180, sellingPrice: 230, stock: 14, minimumStock: 4, unit: 'pack' },
  { id: 'p-soap', name: 'Fresh Soap Bar', sku: 'SOAP-100', category: 'Personal care', purchasePrice: 25, sellingPrice: 38, stock: 30, minimumStock: 8, unit: 'piece' }
]

export const createInitialStore = (): Store => ({ setupCompleted: false, shop: { ...emptyShop }, products: starterProducts.map((product) => ({ ...product })), customers: [], bills: [], updatedAt: 0 })

const storageKey = (userId: string) => `shopflow-pos-store-v1:${userId}`
const cloudKey = (userId: string) => `shopflow:store:${userId}`

const toFiniteNumber = (value: unknown, fallback = 0) => {
  const numericValue = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(numericValue) ? numericValue : fallback
}

const normalizeStore = (parsed: Partial<Store>): Store => {
  const bills = (Array.isArray(parsed.bills) ? parsed.bills : []).map((bill) => {
    const items = (bill.items || []).map((item) => {
      const price = Number.isFinite(item.price) && item.price > 0 ? item.price : 0
      const quantity = Number.isFinite(item.quantity) && item.quantity > 0 ? item.quantity : 1
      const discountScope: 'line' | 'per-unit' = item.discountScope === 'line' ? 'line' : 'per-unit'
      const requestedDiscount = Number.isFinite(item.discount) ? item.discount : 0
      const maximumDiscount = discountScope === 'line' ? price * quantity : price
      const discount = Math.min(maximumDiscount, Math.max(0, requestedDiscount))
      return { productId: item.productId, name: item.name, sku: item.sku, quantity, price, discount, discountScope }
    })
    const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
    const discount = items.reduce((sum, item) => sum + (item.discountScope === 'line' ? item.discount : item.discount * item.quantity), 0)
    return { ...bill, items, subtotal, discount, total: Math.max(0, subtotal - discount) }
  })
  const products = (Array.isArray(parsed.products) ? parsed.products : [])
    .filter((product): product is Product => Boolean(product) && typeof product === 'object')
    .map((product) => ({
      ...product,
      name: typeof product.name === 'string' ? product.name : '',
      sku: typeof product.sku === 'string' ? product.sku : '',
      category: typeof product.category === 'string' ? product.category : '',
      unit: typeof product.unit === 'string' && product.unit.trim() ? product.unit : 'piece',
      purchasePrice: Math.max(0, toFiniteNumber(product.purchasePrice)),
      sellingPrice: Math.max(0, toFiniteNumber(product.sellingPrice)),
      stock: toFiniteNumber(product.stock),
      minimumStock: Math.max(0, toFiniteNumber(product.minimumStock)),
    }))
  return { ...createInitialStore(), ...parsed, shop: { ...emptyShop, ...parsed.shop }, products, bills, updatedAt: Number.isFinite(parsed.updatedAt) ? Number(parsed.updatedAt) : 0 }
}

export const loadStore = (userId: string): Store => {
  try {
    const raw = window.localStorage.getItem(storageKey(userId))
    return raw ? normalizeStore(JSON.parse(raw) as Store) : createInitialStore()
  } catch { return createInitialStore() }
}

/**
 * Keeps an immediate on-device recovery copy. Returning an error instead of throwing
 * lets the cloud save continue when a browser blocks local storage or it is full.
 */
export const saveStore = (userId: string, store: Store): string | null => {
  try {
    window.localStorage.setItem(storageKey(userId), JSON.stringify(store))
    return null
  } catch (error: unknown) {
    return error instanceof Error ? error.message : "The browser could not save a local recovery copy."
  }
}

/** Cloud-synced store, scoped to the authenticated GenMB user. */
export const loadStoreFromKv = async (userId: string): Promise<Store | null> => {
  const stored = await window.genmb.kv.get(cloudKey(userId))
  return stored ? normalizeStore(stored as Store) : null
}

export const saveStoreToKv = async (userId: string, store: Store): Promise<void> => {
  await window.genmb.kv.set(cloudKey(userId), store)
}
