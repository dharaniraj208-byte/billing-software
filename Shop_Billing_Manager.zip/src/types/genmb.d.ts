export {}

declare global {
  type GenMBUser = { id: string; email: string; name: string; picture: string }
  type GenMBSavedView = { id: string; name: string; state: unknown; createdAt: string }
  interface Window {
    genmb: {
      auth: {
        ready: () => Promise<void>
        signIn: () => Promise<GenMBUser | null>
        sendMagicLink: (email: string) => Promise<{ success: boolean; data: unknown }>
        signUp: (email: string, password: string, name?: string) => Promise<{ success: boolean; data: unknown }>
        verifySignUp: (email: string, code: string) => Promise<GenMBUser | null>
        signInWithPassword: (email: string, password: string) => Promise<GenMBUser | null>
        requestPasswordReset: (email: string) => Promise<void>
        confirmPasswordReset: (email: string, code: string, newPassword: string) => Promise<{ success: boolean; data: unknown }>
        signOut: () => Promise<void>
        getUser: () => GenMBUser | null
        isAuthenticated: () => boolean
        onAuthStateChange: (callback: (user: GenMBUser | null) => void) => () => void
      }
      kv: {
        get: (key: string) => Promise<unknown | null>
        set: (key: string, value: unknown) => Promise<void>
        delete: (key: string) => Promise<{ deleted: boolean }>
        list: (prefix: string) => Promise<{ data: Array<{ key: string; value: unknown }>; total: number }>
        increment: (key: string, by?: number) => Promise<number>
      }
      adminTable: {
        buildEmptyView: () => { filters: unknown[]; sort: unknown; hiddenColumns: string[]; pageSize: number; groupBy: string | null }
        filterRows: <T>(rows: T[], filters: unknown[]) => T[]
        exportCsv: (rows: unknown[], columns: unknown[]) => void
        exportXlsx: (rows: unknown[], columns: unknown[]) => Promise<void>
      }
      inventory: {
        variants: { list: (options?: { productId?: string }) => Promise<unknown[]>; create: (data: unknown) => Promise<unknown> }
        locations: { list: () => Promise<unknown[]>; create: (data: unknown) => Promise<unknown> }
        stock: { level: (variantId: string, locationId: string) => Promise<unknown>; adjust: (variantId: string, locationId: string, delta: number, reason: string) => Promise<unknown>; transfer: (variantId: string, fromLocationId: string, toLocationId: string, quantity: number) => Promise<unknown> }
      }
      invoicing: {
        clients: { list: () => Promise<unknown[]>; create: (data: unknown) => Promise<unknown> }
        invoices: { list: (options?: { status?: string; clientId?: string }) => Promise<unknown[]>; get: (id: string) => Promise<unknown>; create: (data: unknown) => Promise<unknown>; markPaid: (id: string, data?: unknown) => Promise<unknown>; send: (id: string) => Promise<unknown>; downloadPdf: (id: string) => Promise<void>; void: (id: string) => Promise<unknown> }
        payments: { record: (data: unknown) => Promise<unknown> }
      }
    }
  }
}
