import React from 'react'
import ReactDOM from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import App from './App'
import './styles/main.css'
import AppErrorBoundary from './components/AppErrorBoundary'

ReactDOM.createRoot(document.getElementById('root')!).render(<AppErrorBoundary><React.StrictMode><HashRouter><App /></HashRouter></React.StrictMode></AppErrorBoundary>)
