import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import {
  BarChart3,
  CalendarDays,
  ChevronDown,
  CircleDollarSign,
  ClipboardList,
  CreditCard,
  Download,
  FileText,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Plus,
  Printer,
  ReceiptText,
  Search,
  Settings,
  ShoppingBag,
  Trash2,
  Upload,
  Users,
  WalletCards,
  X,
} from "lucide-react";
import {
  Bill,
  BillItem,
  Customer,
  PaymentMethod,
  Product,
  Shop,
  Store,
  loadStore,
  loadStoreFromKv,
  saveStore,
  saveStoreToKv,
  starterProducts,
} from "./lib/data";
import { cn, formatCurrency, formatDateTime, toLocalDate } from "./lib/utils";
import { Button, EmptyState, Field, Input, Modal, StatusBadge, ToastProvider, useToast } from "./components/ui";

const navItems = [
  { to: "/", label: "Home", icon: LayoutDashboard },
  { to: "/bill", label: "Create Bill", icon: ReceiptText },
  { to: "/products", label: "Products", icon: Package },
  { to: "/customers", label: "Customers", icon: Users },
  { to: "/bills", label: "Bills", icon: ClipboardList },
  { to: "/reports", label: "Reports", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings },
];

type StoreApi = { store: Store; commit: (updater: (previous: Store) => Store) => Promise<void> };

const isLowStock = (product: Product) => {
  const stock = Number(product.stock);
  const minimumStock = Number(product.minimumStock);
  return Number.isFinite(stock) && Number.isFinite(minimumStock) && stock <= minimumStock;
};

const isKilogramUnit = (unit: string) => ["kg", "kgs", "kilogram", "kilograms"].includes(unit.trim().toLowerCase());

const formatProductQuantity = (quantity: number, unit: string) => {
  if (isKilogramUnit(unit)) return `${Math.round(quantity * 1000).toLocaleString()} g`;
  return `${quantity} ${unit}`;
};

export default function App() {
  return (
    <ToastProvider>
      <AuthGate />
    </ToastProvider>
  );
}

function AuthGate() {
  const [user, setUser] = useState<GenMBUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState("");
  useEffect(() => {
    let active = true;
    const unsubscribe = window.genmb.auth.onAuthStateChange((nextUser) => {
      if (active) setUser(nextUser);
    });
    window.genmb.auth
      .ready()
      .then(() => {
        if (active) setUser(window.genmb.auth.getUser());
      })
      .catch(() => {
        if (active) setAuthError("We could not check your secure session. Please try again.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
      unsubscribe();
    };
  }, []);
  if (loading)
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="h-12 w-12 animate-pulse rounded-xl bg-muted" aria-label="Loading ShopMate" />
      </div>
    );
  if (!user) return <LoginPage initialError={authError} />;
  return <ShopApp user={user} />;
}

function LoginPage({ initialError }: { initialError: string }) {
  const [mode, setMode] = useState<"login" | "signup" | "verify" | "reset">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [message, setMessage] = useState(initialError);
  const [pending, setPending] = useState(false);
  const run = async (action: () => Promise<void>) => {
    setPending(true);
    setMessage("");
    try {
      await action();
    } catch (error: unknown) {
      setMessage(error instanceof Error ? error.message : "Something went wrong. Please try again.");
    } finally {
      setPending(false);
    }
  };
  const handleLogin = (event: FormEvent) => {
    event.preventDefault();
    void run(async () => {
      const signedIn = await window.genmb.auth.signInWithPassword(email, password);
      if (!signedIn) setMessage("Sign-in did not complete. Check your details and try again.");
    });
  };
  const handleGoogle = () =>
    void run(async () => {
      const signedIn = await window.genmb.auth.signIn();
      if (!signedIn) setMessage("Google sign-in was cancelled.");
    });
  const handleMagic = () =>
    void run(async () => {
      await window.genmb.auth.sendMagicLink(email);
      setMessage("Check your email for a secure sign-in link.");
    });
  const handleSignup = (event: FormEvent) => {
    event.preventDefault();
    void run(async () => {
      await window.genmb.auth.signUp(email, password, name);
      setMode("verify");
      setMessage("Check your email for the 6-digit verification code.");
    });
  };
  const handleVerify = (event: FormEvent) => {
    event.preventDefault();
    void run(async () => {
      const signedIn = await window.genmb.auth.verifySignUp(email, code);
      if (!signedIn) setMessage("That code could not be verified. Please try again.");
    });
  };
  const handleReset = (event: FormEvent) => {
    event.preventDefault();
    void run(async () => {
      await window.genmb.auth.requestPasswordReset(email);
      setMessage("Check your email for password reset instructions.");
    });
  };
  const heading =
    mode === "signup"
      ? "Create your shop account"
      : mode === "verify"
        ? "Verify your email"
        : mode === "reset"
          ? "Reset your password"
          : "Welcome back";
  return (
    <main className="relative min-h-screen overflow-hidden bg-background p-4 sm:p-6">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_18%,color-mix(in_srgb,var(--cyan-bright)_18%,transparent),transparent_29%),radial-gradient(circle_at_89%_84%,color-mix(in_srgb,var(--navy)_12%,transparent),transparent_25%)]" />
      <div className="relative mx-auto grid min-h-[calc(100vh-2rem)] max-w-6xl overflow-hidden rounded-[1.75rem] border border-border bg-card shadow-2xl shadow-navy/15 md:grid-cols-[1.08fr_.92fr]">
        <section className="relative hidden overflow-hidden bg-navy p-10 text-navy-foreground md:flex md:flex-col md:justify-between">
          <div className="absolute -right-28 -top-28 h-80 w-80 rounded-full border border-primary-foreground/15" />
          <div className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-cyan-bright/15 blur-2xl" />
          <div className="relative">
            <div className="flex items-center gap-3 text-xl font-bold tracking-tight">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-cyan-bright text-primary-foreground shadow-lg shadow-cyan-bright/20">
                <ShoppingBag size={21} />
              </span>{" "}
              ShopMate
            </div>
            <div className="mt-16 inline-flex items-center rounded-full border border-primary-foreground/20 bg-primary-foreground/10 px-3 py-1 text-xs font-semibold tracking-wide text-primary-foreground">
              YOUR SHOP, IN CONTROL
            </div>
            <p className="mt-5 max-w-md text-4xl font-bold leading-[1.12]">Run every sale with calm confidence.</p>
            <p className="mt-5 max-w-md text-primary-foreground/75">
              Create bills quickly, keep stock accurate, and make every customer visit feel effortless.
            </p>
          </div>
          <div className="relative">
            <div className="mb-5 h-px w-16 bg-cyan-bright/80" />
            <p className="text-sm font-medium text-primary-foreground/70">Fast • Simple • Made for shop owners</p>
          </div>
        </section>
        <section className="flex items-center bg-card p-6 sm:p-10">
          <div className="mx-auto w-full max-w-sm">
            <div className="mb-8 md:hidden">
              <div className="flex items-center gap-3 text-xl font-bold text-navy">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-navy text-cyan-bright">
                  <ShoppingBag size={21} />
                </span>{" "}
                ShopMate
              </div>
            </div>
            <div className="mb-8 h-1 w-10 rounded-full bg-cyan-bright" />
            <h1 className="text-3xl font-bold tracking-tight text-foreground">{heading}</h1>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Securely access your billing and inventory workspace.
            </p>
            {message && (
              <div
                role="status"
                className="mt-5 rounded-xl border border-primary/20 bg-primary/10 p-3 text-sm text-secondary-foreground"
              >
                {message}
              </div>
            )}
            {mode === "verify" ? (
              <form className="mt-6 space-y-4" onSubmit={handleVerify}>
                <Field label="Verification code" id="verification-code">
                  <Input
                    id="verification-code"
                    value={code}
                    onChange={(event) => setCode(event.target.value)}
                    inputMode="numeric"
                    required
                    placeholder="6-digit code"
                  />
                </Field>
                <Button className="w-full" type="submit" loading={pending}>
                  Verify &amp; continue
                </Button>
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className="w-full text-sm font-semibold text-muted-foreground hover:text-foreground hover:underline"
                >
                  Back to sign in
                </button>
              </form>
            ) : mode === "reset" ? (
              <form className="mt-6 space-y-4" onSubmit={handleReset}>
                <Field label="Email address" id="reset-email">
                  <Input
                    id="reset-email"
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    required
                    placeholder="you@shop.com"
                  />
                </Field>
                <Button className="w-full" type="submit" loading={pending}>
                  Send reset instructions
                </Button>
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className="w-full text-sm font-semibold text-muted-foreground hover:text-foreground hover:underline"
                >
                  Back to sign in
                </button>
              </form>
            ) : mode === "signup" ? (
              <form className="mt-6 space-y-4" onSubmit={handleSignup}>
                <Field label="Your name" id="signup-name">
                  <Input
                    id="signup-name"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    required
                    placeholder="Owner name"
                  />
                </Field>
                <Field label="Email address" id="signup-email">
                  <Input
                    id="signup-email"
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    required
                    placeholder="you@shop.com"
                  />
                </Field>
                <Field label="Password" id="signup-password">
                  <Input
                    id="signup-password"
                    type="password"
                    minLength={8}
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    required
                    placeholder="At least 8 characters"
                  />
                </Field>
                <Button className="w-full" type="submit" loading={pending}>
                  Create account
                </Button>
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className="w-full text-sm font-medium text-primary hover:underline"
                >
                  Already have an account? Sign in
                </button>
              </form>
            ) : (
              <form className="mt-6 space-y-4" onSubmit={handleLogin}>
                <Field label="Email address" id="login-email">
                  <Input
                    id="login-email"
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    required
                    placeholder="you@shop.com"
                  />
                </Field>
                <Field label="Password" id="login-password">
                  <Input
                    id="login-password"
                    type="password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    required
                    placeholder="Your password"
                  />
                </Field>
                <Button className="w-full" type="submit" loading={pending}>
                  Sign in
                </Button>
                <button
                  type="button"
                  onClick={() => setMode("reset")}
                  className="w-full text-sm font-semibold text-muted-foreground hover:text-foreground hover:underline"
                >
                  Forgot password?
                </button>
                <div className="relative py-2 text-center text-xs text-muted-foreground before:absolute before:left-0 before:top-1/2 before:h-px before:w-full before:bg-border">
                  <span className="relative bg-card px-2">or</span>
                </div>
                <Button
                  type="button"
                  onClick={handleGoogle}
                  loading={pending}
                  className="w-full bg-secondary text-secondary-foreground shadow-none hover:bg-accent"
                >
                  Continue with Google
                </Button>
                <Button
                  type="button"
                  onClick={handleMagic}
                  loading={pending}
                  className="w-full bg-card text-foreground shadow-none ring-1 ring-border hover:bg-muted"
                >
                  Email me a magic link
                </Button>
                <p className="pt-2 text-center text-sm text-muted-foreground">
                  New here?{" "}
                  <button
                    type="button"
                    onClick={() => setMode("signup")}
                    className="font-semibold text-primary hover:text-cyan-bright hover:underline"
                  >
                    Create an account
                  </button>
                </p>
              </form>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}

function ShopApp({ user }: { user: GenMBUser }) {
  const { toast } = useToast();
  const [store, setStore] = useState<Store>(() => loadStore(user.id));
  const storeRef = useRef(store);
  const cloudReadyRef = useRef(false);
  const syncQueueRef = useRef<Promise<void>>(Promise.resolve());
  const [menuOpen, setMenuOpen] = useState(false);
  const [cloudLoading, setCloudLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [cloudError, setCloudError] = useState("");
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    let active = true;
    const localStore = loadStore(user.id);
    storeRef.current = localStore;
    cloudReadyRef.current = false;
    setStore(localStore);
    setCloudLoading(true);
    setCloudError("");
    void (async () => {
      try {
        const remoteStore = await loadStoreFromKv(user.id);
        if (!active) return;
        // Keep the newest copy. This prevents an older cloud response from restoring
        // stock quantities after a bill was just completed and the browser was closed.
        const newestStore = remoteStore && remoteStore.updatedAt >= localStore.updatedAt ? remoteStore : localStore;
        storeRef.current = newestStore;
        setStore(newestStore);
        const cacheError = saveStore(user.id, newestStore);
        if (cacheError) setCloudError(`Local recovery copy could not be updated: ${cacheError}`);
        cloudReadyRef.current = true;
        if (!remoteStore || newestStore === localStore) await saveStoreToKv(user.id, newestStore);
      } catch (error: unknown) {
        if (!active) return;
        cloudReadyRef.current = true;
        setCloudError(error instanceof Error ? error.message : "Unable to sync your shop data.");
      } finally {
        if (active) setCloudLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [user.id]);
  const commit = async (updater: (previous: Store) => Store) => {
    // Write the exact same snapshot to the on-device recovery copy and the
    // user-scoped cloud record. The local copy is intentionally written first so
    // a completed bill/product update survives an immediate browser close.
    const next = { ...updater(storeRef.current), updatedAt: Date.now() };
    storeRef.current = next;
    const cacheError = saveStore(user.id, next);
    setStore(next);
    if (!cloudReadyRef.current) {
      if (cacheError) throw new Error(cacheError);
      return;
    }

    setSyncing(true);
    const write = syncQueueRef.current
      .catch(() => undefined)
      .then(async () => {
        await saveStoreToKv(user.id, next);
      });
    syncQueueRef.current = write;
    try {
      await write;
      if (cacheError) {
        setCloudError(`Saved securely, but the on-device recovery copy could not be updated: ${cacheError}`);
        toast({ variant: "info", title: "Saved securely", description: "Your changes are stored in your account." });
      } else {
        setCloudError("");
      }
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Unable to sync your shop data.";
      const savedOnDevice = !cacheError;
      setCloudError(savedOnDevice ? `Cloud sync needs attention: ${message}` : message);
      if (savedOnDevice) {
        toast({
          variant: "error",
          title: "Saved on this device only",
          description: `Cloud sync did not finish: ${message}`,
        });
        // The data was successfully persisted in local storage, so callers can
        // close their form and show their normal saved state.
        return;
      }
      throw error;
    } finally {
      if (syncQueueRef.current === write) setSyncing(false);
    }
  };
  if (cloudLoading)
    return (
      <div className="grid min-h-screen place-items-center gap-3 bg-muted/40">
        <div className="h-10 w-10 animate-pulse rounded-xl bg-primary/20" />
        <p className="text-sm text-muted-foreground">Loading your secure shop data…</p>
      </div>
    );
  if (!store.setupCompleted) return <SetupPage user={user} store={store} commit={commit} />;
  const logout = async () => {
    try {
      await window.genmb.auth.signOut();
    } catch {
      /* Auth errors are handled below by state change; preserve workspace. */
    }
  };
  return (
    <div className="min-h-screen bg-muted/40">
      {cloudError && (
        <div
          role="alert"
          className="no-print border-b border-destructive/30 bg-destructive/5 px-4 py-2 text-center text-sm text-destructive"
        >
          Cloud sync needs attention: {cloudError}. Your latest changes remain saved on this device.
        </div>
      )}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-navy bg-navy p-4 text-navy-foreground transition-transform lg:translate-x-0",
          menuOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between px-2 py-3">
          <button
            type="button"
            onClick={() => navigate("/")}
            className="flex min-w-0 items-center gap-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <ShopLogo shop={store.shop} />
            <span className="min-w-0">
              <span className="block truncate text-base font-bold text-navy-foreground">{store.shop.shopName}</span>
              <span className="block text-xs font-medium text-primary-foreground/65">ShopMate POS</span>
            </span>
          </button>
          <button
            type="button"
            className="rounded-md p-2 text-navy-foreground hover:bg-primary-foreground/10 lg:hidden"
            aria-label="Close navigation"
            onClick={() => setMenuOpen(false)}
          >
            <X size={20} />
          </button>
        </div>
        <nav aria-label="Main navigation" className="mt-8 space-y-1">
          {navItems.map(({ to, label, icon: Icon }) => (
            <button
              key={to}
              type="button"
              onClick={() => {
                navigate(to);
                setMenuOpen(false);
              }}
              className={cn(
                "flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm font-medium transition hover:bg-primary-foreground/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-bright",
                location.pathname === to && "bg-primary text-primary-foreground shadow-sm",
              )}
            >
              <Icon size={19} />
              {label}
            </button>
          ))}
        </nav>
        <div className="mt-auto border-t border-primary-foreground/15 pt-4">
          <div className="mb-3 flex items-center gap-3 px-2">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-primary-foreground/10 font-bold text-cyan-bright">
              {(user.name || user.email).slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{user.name || "Shop owner"}</p>
              <p className="truncate text-xs text-primary-foreground/65">{user.email}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => void logout()}
            className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-primary-foreground/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-bright"
          >
            <LogOut size={19} />
            Logout
          </button>
        </div>
      </aside>
      {menuOpen && (
        <button
          type="button"
          aria-label="Close navigation overlay"
          onClick={() => setMenuOpen(false)}
          className="fixed inset-0 z-30 bg-foreground/20 lg:hidden"
        />
      )}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-navy bg-navy px-4 text-navy-foreground shadow-sm lg:px-8">
          <div className="flex min-w-0 items-center gap-2">
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-label="Open navigation"
              className="rounded-md p-2 hover:bg-primary-foreground/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-bright lg:hidden"
            >
              <Menu size={21} />
            </button>
            <div className="flex min-w-0 items-center gap-2 lg:hidden">
              <ShopLogo shop={store.shop} size="sm" />
              <span className="truncate text-sm font-bold text-navy-foreground">{store.shop.shopName}</span>
            </div>
          </div>
          <p className="hidden text-sm text-primary-foreground/70 sm:block">
            {syncing ? "Saving changes securely…" : `${store.shop.shopName} · Simple billing workspace`}
          </p>
          <Button type="button" onClick={() => navigate("/bill")} className="min-h-9 px-3">
            <Plus size={17} />
            Create bill
          </Button>
        </header>
        <main className="mx-auto max-w-7xl p-4 sm:p-6 lg:p-8">
          <Routes>
            <Route path="/" element={<Dashboard store={store} />} />
            <Route path="/bill" element={<BillingPage store={store} commit={commit} />} />
            <Route path="/products" element={<ProductsPage store={store} commit={commit} />} />
            <Route path="/customers" element={<CustomersPage store={store} commit={commit} />} />
            <Route path="/bills" element={<BillsPage store={store} />} />
            <Route path="/reports" element={<ReportsPage store={store} />} />
            <Route path="/settings" element={<SettingsPage user={user} store={store} commit={commit} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function PageMeta({ title, description }: { title: string; description: string }) {
  useEffect(() => {
    document.title = `${title} | ShopMate POS`;
    document.querySelector('meta[name="description"]')?.setAttribute("content", description);
  }, [title, description]);
  return null;
}

function ShopLogo({ shop, size = "md" }: { shop: Shop; size?: "sm" | "md" }) {
  const [imageFailed, setImageFailed] = useState(false);
  const dimensions = size === "sm" ? "h-8 w-8" : "h-10 w-10";
  if (shop.logo && !imageFailed)
    return (
      <img
        src={shop.logo}
        alt={`${shop.shopName} logo`}
        className={cn(dimensions, "shrink-0 rounded-xl border border-border bg-card object-cover shadow-sm")}
        onError={() => setImageFailed(true)}
      />
    );
  return (
    <span
      aria-hidden="true"
      className={cn(
        "grid shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm",
        dimensions,
      )}
    >
      <ShoppingBag size={size === "sm" ? 17 : 21} />
    </span>
  );
}

function PageHead({ title, text, action }: { title: string; text: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{text}</p>
      </div>
      {action}
    </div>
  );
}

function SetupPage({ user, store, commit }: { user: GenMBUser; store: Store; commit: StoreApi["commit"] }) {
  const { toast } = useToast();
  const [shop, setShop] = useState<Shop>(() => ({
    ...store.shop,
    ownerName: user.name || "",
    email: user.email || "",
  }));
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const set = <K extends keyof Shop>(key: K, value: Shop[K]) => setShop((current) => ({ ...current, [key]: value }));
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!shop.shopName.trim() || !shop.ownerName.trim() || !shop.mobile.trim() || !shop.address.trim()) {
      setError("Please fill in the required shop details.");
      return;
    }
    setPending(true);
    try {
      await commit((current) => ({ ...current, setupCompleted: true, shop }));
      toast({ variant: "success", title: "Shop setup saved", description: "Your billing workspace is ready." });
    } catch {
      toast({ variant: "error", title: "Could not save setup", description: "Please try again." });
    } finally {
      setPending(false);
    }
  };
  return (
    <main className="min-h-screen bg-muted/50 p-4 sm:p-8">
      <PageMeta title="Set up your shop" description="Set up your ShopMate billing workspace." />
      <section className="mx-auto max-w-3xl">
        <div className="mb-6 flex items-center gap-2 text-xl font-bold text-primary">
          <ShoppingBag size={25} /> ShopMate
        </div>
        <div className="rounded-xl border bg-card p-5 shadow-sm sm:p-8">
          <h1 className="text-2xl font-bold">Set up your shop</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Add your business details once. Your shop name and contact details will appear on every invoice.
          </p>
          <form className="mt-8 space-y-5" onSubmit={submit}>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Shop name *" id="setup-shop">
                <Input
                  id="setup-shop"
                  value={shop.shopName}
                  onChange={(event) => set("shopName", event.target.value)}
                  required
                />
              </Field>
              <Field label="Owner name *" id="setup-owner">
                <Input
                  id="setup-owner"
                  value={shop.ownerName}
                  onChange={(event) => set("ownerName", event.target.value)}
                  required
                />
              </Field>
              <Field label="Mobile number *" id="setup-mobile">
                <Input
                  id="setup-mobile"
                  value={shop.mobile}
                  onChange={(event) => set("mobile", event.target.value)}
                  required
                  inputMode="tel"
                />
              </Field>
              <Field label="Email address" id="setup-email">
                <Input
                  id="setup-email"
                  type="email"
                  value={shop.email}
                  onChange={(event) => set("email", event.target.value)}
                />
              </Field>
            </div>
            <Field label="Shop address *" id="setup-address">
              <Input
                id="setup-address"
                value={shop.address}
                onChange={(event) => set("address", event.target.value)}
                required
              />
            </Field>
            <Field label="Website & invoice logo (optional)" id="setup-logo">
              <Input
                id="setup-logo"
                type="file"
                accept="image/*"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => set("logo", String(reader.result));
                  reader.readAsDataURL(file);
                }}
              />
            </Field>
            {shop.logo && (
              <div className="flex items-center gap-3 rounded-md border bg-muted/40 p-3">
                <ShopLogo shop={shop} />
                <p className="text-sm text-muted-foreground">
                  This logo will appear in your website navigation, billing screen, invoices, and receipts.
                </p>
              </div>
            )}
            {error && (
              <p className="text-sm text-destructive" role="alert">
                {error}
              </p>
            )}
            <div className="flex justify-end">
              <Button type="submit" loading={pending}>
                Save &amp; open dashboard
              </Button>
            </div>
          </form>
        </div>
      </section>
    </main>
  );
}

function Dashboard({ store }: { store: Store }) {
  const navigate = useNavigate();
  const today = toLocalDate(new Date().toISOString());
  const todayBills = store.bills.filter((bill) => toLocalDate(bill.date) === today);
  const sales = todayBills.reduce((sum, bill) => sum + bill.total, 0);
  const low = store.shop.lowStockAlert ? store.products.filter(isLowStock) : [];
  const cards = [
    { label: "Today's sales", value: formatCurrency(sales, store.shop.currency), icon: CircleDollarSign },
    { label: "Bills today", value: todayBills.length, icon: ReceiptText },
    { label: "Total products", value: store.products.length, icon: Package },
    { label: "Low stock items", value: low.length, icon: Package },
  ];
  return (
    <>
      <PageMeta title="Home" description="Overview of today’s sales, products, bills, and inventory alerts." />
      <PageHead
        title="Home"
        text="Your shop at a glance — today’s sales, bills, and stock updates."
        action={
          <div className="flex gap-2">
            <Button
              className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
              onClick={() => navigate("/products")}
            >
              <Plus size={17} />
              Add product
            </Button>
            <Button onClick={() => navigate("/bill")}>
              <ReceiptText size={17} />
              Create new bill
            </Button>
          </div>
        }
      />
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(({ label, value, icon: Icon }) => (
          <article key={label} className="rounded-lg border bg-card p-5 text-card-foreground shadow-sm">
            <div className="flex items-start justify-between">
              <p className="text-sm text-muted-foreground">{label}</p>
              <div className="rounded-md bg-primary/10 p-2 text-primary">
                <Icon size={19} />
              </div>
            </div>
            <p className="mt-4 text-2xl font-bold">{value}</p>
          </article>
        ))}
      </section>
      <section className="mt-6 grid gap-6 xl:grid-cols-[1.4fr_.8fr]">
        <article className="rounded-lg border bg-card text-card-foreground shadow-sm">
          <div className="flex items-center justify-between border-b p-5">
            <div>
              <h2 className="font-bold">Recent bills</h2>
              <p className="mt-1 text-sm text-muted-foreground">Latest completed sales.</p>
            </div>
            <button
              type="button"
              onClick={() => navigate("/bills")}
              className="text-sm font-semibold text-primary hover:underline"
            >
              View all
            </button>
          </div>
          {store.bills.length ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted text-left text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3 font-medium">Invoice</th>
                    <th className="px-4 py-3 font-medium">Customer</th>
                    <th className="px-4 py-3 font-medium">Payment</th>
                    <th className="px-4 py-3 text-right font-medium">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {store.bills.slice(0, 5).map((bill) => (
                    <tr key={bill.id} className="border-t hover:bg-muted/50">
                      <td className="px-4 py-3 font-medium">{bill.invoiceNumber}</td>
                      <td className="px-4 py-3">{bill.customerName || "Walk-in customer"}</td>
                      <td className="px-4 py-3">
                        <StatusBadge>{bill.paymentMethod}</StatusBadge>
                      </td>
                      <td className="px-4 py-3 text-right font-semibold">
                        {formatCurrency(bill.total, store.shop.currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState
              icon={ReceiptText}
              title="No bills today"
              text="Your completed bills will appear here."
              action={
                <Button onClick={() => navigate("/bill")}>
                  <Plus size={17} />
                  Create first bill
                </Button>
              }
            />
          )}
        </article>
        <article className="rounded-lg border bg-card p-5 text-card-foreground shadow-sm">
          <h2 className="font-bold">Low stock alert</h2>
          <p className="mt-1 text-sm text-muted-foreground">Products that need your attention.</p>
          <div className="mt-4 space-y-3">
            {low.length ? (
              low.map((product) => (
                <div key={product.id} className="flex items-center justify-between rounded-md bg-destructive/5 p-3">
                  <div>
                    <p className="text-sm font-semibold">{product.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Only {formatProductQuantity(product.stock, product.unit)} remaining
                    </p>
                  </div>
                  <StatusBadge tone="warning">Low stock</StatusBadge>
                </div>
              ))
            ) : (
              <div className="rounded-md bg-primary/5 p-4 text-sm text-primary">
                All products are above their minimum stock levels.
              </div>
            )}
          </div>
        </article>
      </section>
    </>
  );
}

function ProductForm({
  product,
  onSave,
  onCancel,
}: {
  product?: Product;
  onSave: (product: Product) => Promise<void>;
  onCancel: () => void;
}) {
  const [form, setForm] = useState<Product>(
    product || {
      id: "",
      name: "",
      sku: "",
      category: "",
      purchasePrice: 0,
      sellingPrice: 0,
      stock: 0,
      minimumStock: 0,
      unit: "piece",
    },
  );
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const set = <K extends keyof Product>(key: K, value: Product[K]) =>
    setForm((current) => ({ ...current, [key]: value }));
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!form.name.trim() || !form.sku.trim() || !form.category.trim()) {
      setError("Product name, SKU, and category are required.");
      return;
    }
    setPending(true);
    try {
      await onSave({ ...form, id: form.id || crypto.randomUUID() });
    } finally {
      setPending(false);
    }
  };
  return (
    <form className="space-y-4" onSubmit={submit}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Product name *" id="product-name">
          <Input id="product-name" value={form.name} onChange={(event) => set("name", event.target.value)} required />
        </Field>
        <Field label="Product code / SKU *" id="product-sku">
          <Input id="product-sku" value={form.sku} onChange={(event) => set("sku", event.target.value)} required />
        </Field>
        <Field label="Category *" id="product-category">
          <Input
            id="product-category"
            value={form.category}
            onChange={(event) => set("category", event.target.value)}
            required
          />
        </Field>
        <Field label="Unit" id="product-unit">
          <Input
            id="product-unit"
            list="product-unit-options"
            value={form.unit}
            onChange={(event) => set("unit", event.target.value)}
            placeholder="Select or enter a unit"
          />
          <datalist id="product-unit-options">
            <option value="piece" />
            <option value="grams" />
            <option value="kg" />
            <option value="litre" />
            <option value="box" />
            <option value="packet" />
          </datalist>
        </Field>
        <Field label={isKilogramUnit(form.unit) ? "Purchase price per kg" : "Purchase price"} id="product-purchase">
          <Input
            id="product-purchase"
            type="number"
            min="0"
            value={form.purchasePrice}
            onChange={(event) => set("purchasePrice", Number(event.target.value))}
          />
        </Field>
        <Field label={isKilogramUnit(form.unit) ? "Selling price per kg" : "Selling price"} id="product-selling">
          <Input
            id="product-selling"
            type="number"
            min="0"
            value={form.sellingPrice}
            onChange={(event) => set("sellingPrice", Number(event.target.value))}
          />
        </Field>
        <Field label={isKilogramUnit(form.unit) ? "Current stock in kg" : "Current stock quantity"} id="product-stock">
          <Input
            id="product-stock"
            type="number"
            value={form.stock}
            onChange={(event) => set("stock", Number(event.target.value))}
          />
        </Field>
        <Field label={isKilogramUnit(form.unit) ? "Minimum stock alert in kg" : "Minimum stock alert"} id="product-minimum">
          <Input
            id="product-minimum"
            type="number"
            min="0"
            value={form.minimumStock}
            onChange={(event) => set("minimumStock", Number(event.target.value))}
          />
        </Field>
      </div>
      <Field label="Product image URL (optional)" id="product-image">
        <Input
          id="product-image"
          type="url"
          value={form.image || ""}
          onChange={(event) => set("image", event.target.value)}
          placeholder="https://..."
        />
      </Field>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button
          type="button"
          onClick={onCancel}
          disabled={pending}
          className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
        >
          Cancel
        </Button>
        <Button type="submit" loading={pending}>
          Save product
        </Button>
      </div>
    </form>
  );
}

function ProductsPage({ store, commit }: StoreApi) {
  const { toast } = useToast();
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Product | null | "new">(null);
  const [deleting, setDeleting] = useState<Product | null>(null);
  const [importing, setImporting] = useState(false);
  const [importPending, setImportPending] = useState(false);
  const [importError, setImportError] = useState("");
  const products = store.products.filter((product) =>
    `${product.name} ${product.sku}`.toLowerCase().includes(query.toLowerCase()),
  );
  const saveProduct = async (product: Product) => {
    const exists = store.products.some((item) => item.id === product.id);
    try {
      await commit((current) => ({
        ...current,
        products: exists
          ? current.products.map((item) => (item.id === product.id ? product : item))
          : [product, ...current.products],
      }));
      setEditing(null);
      toast({
        variant: "success",
        title: exists ? "Product updated successfully" : "Product added successfully",
        description: `${product.name} is saved and ready to bill.`,
      });
    } catch {
      toast({
        variant: "error",
        title: "Could not save product",
        description: "The product remains saved on this device. Please check your connection and try again.",
      });
    }
  };
  const remove = async () => {
    if (!deleting) return;
    try {
      const name = deleting.name;
      await commit((current) => ({
        ...current,
        products: current.products.filter((product) => product.id !== deleting.id),
      }));
      setDeleting(null);
      toast({ variant: "success", title: "Product deleted", description: `${name} was removed from inventory.` });
    } catch {
      toast({ variant: "error", title: "Could not delete product", description: "Please try again." });
    }
  };
  const downloadTemplate = () => {
    try {
      const csv =
        "Product Name,SKU,Category,Purchase Price,Selling Price,Current Stock,Minimum Stock,Unit,Image URL\nPremium Rice 5kg,RICE-5,Groceries,410,500,20,5,bag,";
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "shopmate-product-import-template.csv";
      link.click();
      URL.revokeObjectURL(link.href);
      toast({
        variant: "success",
        title: "Template downloaded",
        description: "Fill it in, save as CSV, then upload it here.",
      });
    } catch (error: unknown) {
      toast({
        variant: "error",
        title: "Could not download template",
        description: error instanceof Error ? error.message : "Please try again.",
      });
    }
  };
  const importProducts = async (file: File) => {
    setImportPending(true);
    setImportError("");
    try {
      const text = await file.text();
      const rows = text
        .split(/\r?\n/)
        .filter((row) => row.trim())
        .map((row) => row.split(",").map((cell) => cell.trim()));
      if (rows.length < 2) throw new Error("Add a header row and at least one product row to the CSV file.");
      const header = rows[0].map((cell) => cell.toLowerCase().replace(/[^a-z0-9]/g, ""));
      const column = (names: string[]) => header.findIndex((cell) => names.includes(cell));
      const nameIndex = column(["productname", "name"]);
      const skuIndex = column(["sku", "productcode", "productcodesku"]);
      const categoryIndex = column(["category"]);
      const purchaseIndex = column(["purchaseprice", "costprice"]);
      const sellingIndex = column(["sellingprice", "price"]);
      const stockIndex = column(["currentstock", "stock", "stockquantity"]);
      const minimumIndex = column(["minimumstock", "minimumstockalert", "minimumstockalertquantity"]);
      const unitIndex = column(["unit"]);
      const imageIndex = column(["imageurl", "image"]);
      if ([nameIndex, skuIndex, categoryIndex, sellingIndex, stockIndex].some((index) => index < 0))
        throw new Error("Required columns: Product Name, SKU, Category, Selling Price, and Current Stock.");
      const imported = rows.slice(1).map((row, rowIndex) => {
        const name = row[nameIndex]?.trim();
        const sku = row[skuIndex]?.trim();
        const category = row[categoryIndex]?.trim();
        if (!name || !sku || !category) throw new Error(`Row ${rowIndex + 2} needs a product name, SKU, and category.`);
        const numberAt = (index: number, fallback = 0) =>
          index < 0 || row[index] === undefined || row[index] === "" ? fallback : Number(row[index]);
        const sellingPrice = numberAt(sellingIndex);
        const purchasePrice = numberAt(purchaseIndex);
        const stock = numberAt(stockIndex);
        const minimumStock = numberAt(minimumIndex);
        if ([sellingPrice, purchasePrice, stock, minimumStock].some((value) => Number.isNaN(value) || value < 0))
          throw new Error(`Row ${rowIndex + 2} has an invalid price or stock quantity.`);
        return {
          id: crypto.randomUUID(),
          name,
          sku,
          category,
          purchasePrice,
          sellingPrice,
          stock,
          minimumStock,
          unit: unitIndex >= 0 && row[unitIndex] ? row[unitIndex] : "piece",
          image: imageIndex >= 0 && row[imageIndex] ? row[imageIndex] : undefined,
        } satisfies Product;
      });
      await commit((current) => {
        const bySku = new Map(current.products.map((product) => [product.sku.toLowerCase(), product]));
        imported.forEach((product) =>
          bySku.set(product.sku.toLowerCase(), {
            ...product,
            id: bySku.get(product.sku.toLowerCase())?.id || product.id,
          }),
        );
        return { ...current, products: [...bySku.values()] };
      });
      setImporting(false);
      toast({
        variant: "success",
        title: "Products imported",
        description: `${imported.length} product${imported.length === 1 ? "" : "s"} added or updated.`,
      });
    } catch (error: unknown) {
      setImportError(error instanceof Error ? error.message : "Could not read that CSV file.");
    } finally {
      setImportPending(false);
    }
  };
  return (
    <>
      <PageMeta title="Products" description="Manage your shop products, prices, and available inventory." />
      <PageHead
        title="Products"
        text="Add products, update prices, and keep stock accurate."
        action={
          <div className="flex flex-wrap gap-2">
            <Button
              className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
              onClick={() => setImporting(true)}
            >
              <Upload size={17} />
              Import CSV
            </Button>
            <Button onClick={() => setEditing("new")}>
              <Plus size={17} />
              Add product
            </Button>
          </div>
        }
      />
      <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
        <div className="border-b p-4">
          <div className="relative max-w-md">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              aria-label="Search products"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="pl-10"
              placeholder="Search by product name or SKU"
            />
          </div>
        </div>
        {products.length ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="sticky top-0 bg-muted text-left text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Product</th>
                  <th className="px-4 py-3 font-medium">Category</th>
                  <th className="px-4 py-3 text-right font-medium">Selling price</th>
                  <th className="px-4 py-3 text-right font-medium">Stock</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => {
                  const low = isLowStock(product);
                  return (
                    <tr key={product.id} className="border-t hover:bg-muted/50">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          {product.image ? (
                            <img
                              src={product.image}
                              alt={product.name}
                              width="36"
                              height="36"
                              className="h-9 w-9 rounded-md bg-muted object-cover"
                              onError={(event) => {
                                event.currentTarget.style.display = "none";
                              }}
                            />
                          ) : (
                            <div className="grid h-9 w-9 place-items-center rounded-md bg-primary/10 text-primary">
                              <Package size={17} />
                            </div>
                          )}
                          <div>
                            <p className="font-semibold">{product.name}</p>
                            <p className="text-xs text-muted-foreground">{product.sku}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">{product.category}</td>
                      <td className="px-4 py-3 text-right font-medium">
                        {formatCurrency(product.sellingPrice, store.shop.currency)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {formatProductQuantity(product.stock, product.unit)}
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge tone={low ? "warning" : "success"}>{low ? "Low stock" : "In stock"}</StatusBadge>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-2">
                          <Button
                            className="min-h-8 bg-card px-2 text-foreground ring-1 ring-border hover:bg-muted"
                            onClick={() => setEditing(product)}
                          >
                            View / edit
                          </Button>
                          <button
                            type="button"
                            onClick={() => setDeleting(product)}
                            aria-label={`Delete ${product.name}`}
                            className="rounded-md p-2 text-destructive hover:bg-destructive/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          >
                            <Trash2 size={17} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={Package}
            title={query ? "No products found" : "No products yet"}
            text={
              query ? "Try a product name or SKU without filters." : "Add your first item to start billing customers."
            }
            action={
              <Button onClick={() => (query ? setQuery("") : setEditing("new"))}>
                {query ? "Clear search" : "Add product"}
              </Button>
            }
          />
        )}
      </div>
      <Modal
        open={importing}
        title="Import products from CSV"
        onClose={() => {
          if (!importPending) {
            setImporting(false);
            setImportError("");
          }
        }}
      >
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Upload a CSV to add products in bulk. Existing products with the same SKU will be updated.
          </p>
          <div className="rounded-md border bg-muted/40 p-4 text-sm">
            <p className="font-semibold">Required columns</p>
            <p className="mt-1 text-muted-foreground">Product Name, SKU, Category, Selling Price, Current Stock</p>
            <p className="mt-2 text-muted-foreground">Optional: Purchase Price, Minimum Stock, Unit, Image URL.</p>
          </div>
          <Button
            type="button"
            className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
            onClick={downloadTemplate}
            disabled={importPending}
          >
            <Download size={17} />
            Download CSV template
          </Button>
          <Field label="CSV file" id="product-import-file">
            <Input
              id="product-import-file"
              type="file"
              accept=".csv,text/csv"
              disabled={importPending}
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void importProducts(file);
                event.currentTarget.value = "";
              }}
            />
          </Field>
          {importPending && <p className="text-sm text-muted-foreground">Importing products…</p>}
          {importError && (
            <p
              className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive"
              role="alert"
            >
              {importError}
            </p>
          )}
        </div>
      </Modal>
      <Modal
        open={editing !== null}
        title={editing === "new" ? "Add product" : "Edit product"}
        onClose={() => setEditing(null)}
      >
        {editing !== null && (
          <ProductForm
            product={editing === "new" ? undefined : editing}
            onSave={saveProduct}
            onCancel={() => setEditing(null)}
          />
        )}
      </Modal>
      <Modal open={!!deleting} title="Delete product?" onClose={() => setDeleting(null)}>
        <p className="text-sm text-muted-foreground">
          Delete <strong className="text-foreground">{deleting?.name}</strong> permanently? It will no longer be
          available on new bills.
        </p>
        <div className="mt-6 flex justify-end gap-2">
          <Button
            className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
            onClick={() => setDeleting(null)}
          >
            Cancel
          </Button>
          <Button className="bg-destructive text-white hover:bg-destructive/90" onClick={remove}>
            Delete product
          </Button>
        </div>
      </Modal>
    </>
  );
}

function BillingPage({ store, commit }: StoreApi) {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [cart, setCart] = useState<BillItem[]>([]);
  const [search, setSearch] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerMobile, setCustomerMobile] = useState("");
  const [payment, setPayment] = useState<PaymentMethod>("Cash");
  const [received, setReceived] = useState("");
  const [completed, setCompleted] = useState<Bill | null>(null);
  const [error, setError] = useState("");
  const [weighingProduct, setWeighingProduct] = useState<Product | null>(null);
  const [grams, setGrams] = useState("1000");
  const [weightError, setWeightError] = useState("");
  const matches = store.products
    .filter((product) => `${product.name} ${product.sku}`.toLowerCase().includes(search.toLowerCase()))
    .slice(0, 6);
  const lineSubtotal = (item: BillItem) => item.price * item.quantity;
  const lineDiscount = (item: BillItem) =>
    Math.min(lineSubtotal(item), Math.max(0, Number.isFinite(item.discount) ? item.discount : 0));
  const subtotal = cart.reduce((sum, item) => sum + lineSubtotal(item), 0);
  const discount = cart.reduce((sum, item) => sum + lineDiscount(item), 0);
  const total = Math.max(0, subtotal - discount);
  const receivedNumber = Number(received || 0);
  const change = payment === "Credit / Due" ? 0 : Math.max(0, receivedNumber - total);
  const addProductQuantity = (product: Product, quantity: number) => {
    const existing = cart.find((item) => item.productId === product.id);
    const nextQuantity = (existing?.quantity || 0) + quantity;
    if (!Number.isFinite(quantity) || quantity <= 0) {
      setError("Enter a valid quantity.");
      return false;
    }
    if (!store.shop.allowNegativeStock && nextQuantity > product.stock) {
      setError(`Insufficient stock: ${product.name} has ${formatProductQuantity(product.stock, product.unit)} available.`);
      return false;
    }
    if (existing) {
      setCart((current) =>
        current.map((item) => (item.productId === product.id ? { ...item, quantity: nextQuantity } : item)),
      );
    } else {
      setCart((current) => [
        ...current,
        {
          productId: product.id,
          name: product.name,
          sku: product.sku,
          quantity,
          price: product.sellingPrice,
          discount: Math.min(product.sellingPrice * quantity, Math.max(0, store.shop.defaultDiscount)),
          discountScope: "line",
        },
      ]);
    }
    setError("");
    return true;
  };
  const addProduct = (product: Product) => {
    setSearch("");
    if (isKilogramUnit(product.unit)) {
      setWeighingProduct(product);
      setGrams("1000");
      setWeightError("");
      return;
    }
    addProductQuantity(product, 1);
  };
  const confirmWeight = (event: FormEvent) => {
    event.preventDefault();
    if (!weighingProduct) return;
    const selectedGrams = Number(grams);
    if (!Number.isFinite(selectedGrams) || selectedGrams <= 0) {
      setWeightError("Enter a weight greater than 0 grams.");
      return;
    }
    if (addProductQuantity(weighingProduct, selectedGrams / 1000)) {
      setWeighingProduct(null);
      setWeightError("");
    }
  };
  const changeQuantity = (productId: string, next: number) => {
    const product = store.products.find((item) => item.id === productId);
    if (!product || !Number.isFinite(next)) return;
    const minimumQuantity = isKilogramUnit(product.unit) ? 0.001 : 1;
    const normalizedNext = isKilogramUnit(product.unit) ? Math.round(next * 1000) / 1000 : next;
    if (normalizedNext < minimumQuantity) return;
    if (!store.shop.allowNegativeStock && normalizedNext > product.stock) {
      setError(`Insufficient stock: ${product.name} has ${formatProductQuantity(product.stock, product.unit)} available.`);
      return;
    }
    setError("");
    setCart((current) =>
      current.map((item) => (item.productId === productId ? { ...item, quantity: normalizedNext } : item)),
    );
  };
  const updateDiscount = (productId: string, rawValue: string) => {
    const item = cart.find((line) => line.productId === productId);
    if (!item) return;
    const entered = rawValue === "" ? 0 : Number(rawValue);
    if (!Number.isFinite(entered) || entered < 0) {
      setError("Discount must be a valid positive amount.");
      return;
    }
    const maximumDiscount = lineSubtotal(item);
    const cappedDiscount = Math.min(maximumDiscount, entered);
    setCart((current) =>
      current.map((line) =>
        line.productId === productId ? { ...line, discount: cappedDiscount, discountScope: "line" } : line,
      ),
    );
    setError(entered > maximumDiscount ? `Discount for ${item.name} was limited to the line subtotal.` : "");
  };
  const [finishing, setFinishing] = useState(false);
  const finish = async () => {
    if (!cart.length) {
      setError("Add at least one product before completing the bill.");
      return;
    }
    if (payment === "Credit / Due" && !customerName.trim()) {
      setError("Enter the customer name to record a credit / due sale.");
      return;
    }
    if (payment !== "Credit / Due" && receivedNumber < total) {
      setError("Amount received must cover the grand total.");
      return;
    }
    const invoice = `${store.shop.invoicePrefix}${store.shop.nextInvoiceNumber}`;
    const existingCustomer = store.customers.find((customer) => customer.mobile && customer.mobile === customerMobile);
    const customerId = existingCustomer?.id || (customerName.trim() ? crypto.randomUUID() : undefined);
    const bill: Bill = {
      id: crypto.randomUUID(),
      invoiceNumber: invoice,
      date: new Date().toISOString(),
      customerId,
      customerName: customerName.trim(),
      customerMobile: customerMobile.trim(),
      items: cart,
      subtotal,
      discount,
      total,
      paymentMethod: payment,
      amountReceived: payment === "Credit / Due" ? 0 : receivedNumber,
      change,
    };
    setFinishing(true);
    try {
      await commit((current) => {
        const customerList = customerId
          ? existingCustomer
            ? current.customers.map((customer) =>
                customer.id === customerId
                  ? {
                      ...customer,
                      name: customerName.trim() || customer.name,
                      mobile: customerMobile.trim() || customer.mobile,
                      totalPurchases: customer.totalPurchases + total,
                      due: customer.due + (payment === "Credit / Due" ? total : 0),
                    }
                  : customer,
              )
            : [
                ...current.customers,
                {
                  id: customerId,
                  name: customerName.trim() || "Customer",
                  mobile: customerMobile.trim(),
                  address: "",
                  totalPurchases: total,
                  due: payment === "Credit / Due" ? total : 0,
                },
              ]
          : current.customers;
        return {
          ...current,
          shop: { ...current.shop, nextInvoiceNumber: current.shop.nextInvoiceNumber + 1 },
          products: current.products.map((product) => {
            const item = cart.find((cartItem) => cartItem.productId === product.id);
            return item ? { ...product, stock: product.stock - item.quantity } : product;
          }),
          customers: customerList,
          bills: [bill, ...current.bills],
        };
      });
      setCompleted(bill);
      setError("");
      toast({
        variant: "success",
        title: "Bill generated successfully",
        description: `${invoice} has been saved and stock updated.`,
      });
    } catch {
      toast({
        variant: "error",
        title: "Could not complete bill",
        description: "The bill is saved on this device, but cloud sync needs attention.",
      });
    } finally {
      setFinishing(false);
    }
  };
  const newBill = () => {
    setCart([]);
    setWeighingProduct(null);
    setWeightError("");
    setCustomerName("");
    setCustomerMobile("");
    setPayment("Cash");
    setReceived("");
    setCompleted(null);
    setSearch("");
  };
  if (completed) return <InvoiceView store={store} bill={completed} onNew={newBill} />;
  return (
    <>
      <PageMeta
        title="Create bill"
        description="Create a customer bill, update inventory, and generate a professional invoice."
      />
      <PageHead title="Create bill" text="Search products, adjust quantities, choose payment, and finish fast." />
      <div className="grid gap-6 xl:grid-cols-[1.45fr_.75fr]">
        <section className="space-y-5">
          <article className="rounded-lg border bg-card p-5 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <ShopLogo shop={store.shop} />
                <div className="min-w-0">
                  <h2 className="truncate text-lg font-bold">{store.shop.shopName}</h2>
                  <p className="mt-1 truncate text-sm text-muted-foreground">
                    {store.shop.address} · {store.shop.mobile}
                  </p>
                </div>
              </div>
              <StatusBadge>New sale</StatusBadge>
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <Field label="Customer name (optional)" id="bill-customer">
                <Input
                  id="bill-customer"
                  list="customer-list"
                  value={customerName}
                  onChange={(event) => setCustomerName(event.target.value)}
                  placeholder="Walk-in customer"
                />
                <datalist id="customer-list">
                  {store.customers.map((customer) => (
                    <option key={customer.id} value={customer.name} />
                  ))}
                </datalist>
              </Field>
              <Field label="Customer mobile (optional)" id="bill-mobile">
                <Input
                  id="bill-mobile"
                  value={customerMobile}
                  onChange={(event) => setCustomerMobile(event.target.value)}
                  placeholder="Mobile number"
                  inputMode="tel"
                />
              </Field>
            </div>
          </article>
          <article className="rounded-lg border bg-card p-5 shadow-sm">
            <h2 className="font-bold">Add products</h2>
            <div className="relative mt-4">
              <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                autoFocus
                aria-label="Search product to add"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                className="h-12 pl-10 text-base"
                placeholder="Search product name or product code"
              />
              {search && (
                <div className="absolute z-10 mt-2 max-h-72 w-full overflow-y-auto rounded-md border bg-popover p-1 shadow-lg">
                  {matches.length ? (
                    matches.map((product) => (
                      <button
                        type="button"
                        key={product.id}
                        onClick={() => addProduct(product)}
                        className="flex w-full items-center justify-between rounded-md px-3 py-3 text-left hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <div>
                          <p className="font-semibold">{product.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {product.sku} · {formatProductQuantity(product.stock, product.unit)} available
                          </p>
                        </div>
                        <span className="font-semibold">
                          {formatCurrency(product.sellingPrice, store.shop.currency)}{isKilogramUnit(product.unit) ? " / kg" : ""}
                        </span>
                      </button>
                    ))
                  ) : (
                    <p className="p-3 text-sm text-muted-foreground">No matching products found.</p>
                  )}
                </div>
              )}
            </div>
            {error && (
              <div
                className="mt-4 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive"
                role="alert"
              >
                {error}
              </div>
            )}
            <div className="mt-5 overflow-x-auto">
              {cart.length ? (
                <table className="w-full min-w-[620px] text-sm">
                  <thead className="bg-muted text-left text-muted-foreground">
                    <tr>
                      <th className="px-3 py-3 font-medium">Product</th>
                      <th className="px-3 py-3 text-center font-medium">Quantity / weight</th>
                      <th className="px-3 py-3 text-right font-medium">Price</th>
                      <th className="px-3 py-3 text-right font-medium">Discount amount</th>
                      <th className="px-3 py-3 text-right font-medium">Total</th>
                      <th className="px-3 py-3">
                        <span className="sr-only">Remove</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {cart.map((item) => (
                      <tr key={item.productId} className="border-t hover:bg-muted/50">
                        <td className="px-3 py-3">
                          <p className="font-semibold">{item.name}</p>
                          <p className="text-xs text-muted-foreground">{item.sku}</p>
                        </td>
                        <td className="px-3 py-3">
                          {isKilogramUnit(store.products.find((product) => product.id === item.productId)?.unit || "") ? (
                            <div className="mx-auto flex w-36 items-center justify-center rounded-md border">
                              <button
                                type="button"
                                onClick={() => changeQuantity(item.productId, item.quantity - 0.1)}
                                aria-label={`Reduce ${item.name} weight by 100 grams`}
                                className="p-2 hover:bg-accent"
                              >
                                <ChevronDown size={15} className="rotate-90" />
                              </button>
                              <input
                                aria-label={`${item.name} weight in grams`}
                                className="w-16 bg-transparent text-center outline-none"
                                type="number"
                                min="1"
                                step="1"
                                value={Math.round(item.quantity * 1000)}
                                onChange={(event) => changeQuantity(item.productId, Number(event.target.value) / 1000)}
                              />
                              <span className="pr-1 text-xs text-muted-foreground">g</span>
                              <button
                                type="button"
                                onClick={() => changeQuantity(item.productId, item.quantity + 0.1)}
                                aria-label={`Increase ${item.name} weight by 100 grams`}
                                className="p-2 hover:bg-accent"
                              >
                                <Plus size={15} />
                              </button>
                            </div>
                          ) : (
                            <div className="mx-auto flex w-28 items-center justify-center rounded-md border">
                              <button
                                type="button"
                                onClick={() => changeQuantity(item.productId, item.quantity - 1)}
                                aria-label={`Reduce ${item.name} quantity`}
                                className="p-2 hover:bg-accent"
                              >
                                <ChevronDown size={15} className="rotate-90" />
                              </button>
                              <input
                                aria-label={`${item.name} quantity`}
                                className="w-10 bg-transparent text-center outline-none"
                                type="number"
                                min="1"
                                value={item.quantity}
                                onChange={(event) => changeQuantity(item.productId, Number(event.target.value))}
                              />
                              <button
                                type="button"
                                onClick={() => changeQuantity(item.productId, item.quantity + 1)}
                                aria-label={`Increase ${item.name} quantity`}
                                className="p-2 hover:bg-accent"
                              >
                                <Plus size={15} />
                              </button>
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-3 text-right">
                          {formatCurrency(item.price, store.shop.currency)}{isKilogramUnit(store.products.find((product) => product.id === item.productId)?.unit || "") ? " / kg" : ""}
                        </td>
                        <td className="px-3 py-3 text-right">
                          <Input
                            aria-label={`${item.name} discount amount`}
                            className="ml-auto h-8 w-28 text-right"
                            type="number"
                            min="0"
                            max={lineSubtotal(item)}
                            step="0.01"
                            value={lineDiscount(item)}
                            onChange={(event) => updateDiscount(item.productId, event.target.value)}
                          />
                        </td>
                        <td className="px-3 py-3 text-right font-semibold">
                          {formatCurrency(lineSubtotal(item) - lineDiscount(item), store.shop.currency)}
                        </td>
                        <td className="px-3 py-3 text-right">
                          <button
                            type="button"
                            onClick={() =>
                              setCart((current) => current.filter((line) => line.productId !== item.productId))
                            }
                            aria-label={`Remove ${item.name}`}
                            className="rounded-md p-2 text-destructive hover:bg-destructive/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          >
                            <Trash2 size={17} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <EmptyState
                  icon={ShoppingBag}
                  title="Your bill is empty"
                  text="Use the search box above to add products to this bill."
                />
              )}
            </div>
          </article>
        </section>
        <aside className="h-fit rounded-lg border border-primary/30 bg-card p-5 shadow-sm xl:sticky xl:top-24">
          <div className="-mx-5 -mt-5 mb-5 rounded-t-lg bg-navy px-5 py-4 text-navy-foreground">
            <h2 className="text-lg font-bold">Payment</h2>
            <p className="mt-1 text-sm text-primary-foreground/75">Choose how the customer is paying.</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {(["Cash", "UPI", "Card", "Credit / Due"] as PaymentMethod[]).map((method) => (
              <button
                type="button"
                key={method}
                onClick={() => setPayment(method)}
                className={cn(
                  "rounded-md border px-3 py-3 text-sm font-semibold transition hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  payment === method && "border-primary bg-primary/10 text-secondary-foreground ring-2 ring-primary/25",
                )}
              >
                {method}
              </button>
            ))}
          </div>
          {payment !== "Credit / Due" && (
            <div className="mt-5">
              <Field label="Amount received" id="amount-received">
                <Input
                  id="amount-received"
                  type="number"
                  min="0"
                  value={received}
                  onChange={(event) => setReceived(event.target.value)}
                  placeholder={total ? String(total) : "0"}
                />
              </Field>
            </div>
          )}
          <div className="mt-6 space-y-3 border-t pt-5 text-sm">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span>{formatCurrency(subtotal, store.shop.currency)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Discount</span>
              <span>-{formatCurrency(discount, store.shop.currency)}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Enter a currency amount for each product line. This is not a percentage and cannot exceed that line’s
              subtotal.
            </p>
            <div className="flex justify-between rounded-md bg-cyan-bright/15 px-3 py-3 text-lg font-bold text-blue-dark">
              <span>Grand total</span>
              <span>{formatCurrency(total, store.shop.currency)}</span>
            </div>
            {payment !== "Credit / Due" && (
              <div className="flex justify-between font-medium text-success">
                <span>Change</span>
                <span>{formatCurrency(change, store.shop.currency)}</span>
              </div>
            )}
            {payment === "Credit / Due" && (
              <p className="rounded-md bg-destructive/5 p-3 text-sm text-destructive">
                This total will be added to the customer’s outstanding due amount.
              </p>
            )}
          </div>
          <Button
            className="mt-6 w-full bg-cyan-bright text-primary-foreground hover:bg-primary"
            onClick={() => void finish()}
            disabled={!cart.length || finishing}
            loading={finishing}
          >
            <CreditCard size={18} />
            Complete bill
          </Button>
        </aside>
      </div>
      <Modal
        open={!!weighingProduct}
        title="Enter weight in grams"
        onClose={() => {
          setWeighingProduct(null);
          setWeightError("");
        }}
      >
        <form className="space-y-4" onSubmit={confirmWeight}>
          <div className="rounded-md bg-muted p-4">
            <p className="font-semibold">{weighingProduct?.name}</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {weighingProduct && `${formatCurrency(weighingProduct.sellingPrice, store.shop.currency)} per kg`}
            </p>
          </div>
          <Field label="Weight in grams" id="bill-weight-grams">
            <Input
              id="bill-weight-grams"
              type="number"
              min="1"
              step="1"
              inputMode="numeric"
              value={grams}
              onChange={(event) => {
                setGrams(event.target.value);
                setWeightError("");
              }}
              autoFocus
              required
            />
          </Field>
          <div className="grid grid-cols-3 gap-2">
            {[250, 500, 1000].map((weight) => (
              <Button
                key={weight}
                type="button"
                className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
                onClick={() => {
                  setGrams(String(weight));
                  setWeightError("");
                }}
              >
                {weight} g
              </Button>
            ))}
          </div>
          {weightError && <p className="text-sm text-destructive" role="alert">{weightError}</p>}
          <p className="text-sm text-muted-foreground">
            This will be billed as {(Number(grams || 0) / 1000).toFixed(3)} kg and stock will reduce by the same weight.
          </p>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
              onClick={() => setWeighingProduct(null)}
            >
              Cancel
            </Button>
            <Button type="submit">Add to bill</Button>
          </div>
        </form>
      </Modal>
    </>
  );
}

function InvoiceView({ store, bill, onNew }: { store: Store; bill: Bill; onNew: () => void }) {
  const { toast } = useToast();
  const print = () => {
    try {
      window.print();
    } catch {
      toast({ variant: "error", title: "Print could not open", description: "Please try your browser print command." });
    }
  };
  useEffect(() => {
    if (!store.shop.autoPrintReceipt) return;
    const frame = window.requestAnimationFrame(print);
    return () => window.cancelAnimationFrame(frame);
  }, [bill.id, store.shop.autoPrintReceipt]);
  const download = () => {
    try {
      const html = document.getElementById("invoice-print")?.outerHTML || "";
      const blob = new Blob([`<html><head><title>${bill.invoiceNumber}</title></head><body>${html}</body></html>`], {
        type: "text/html",
      });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `${bill.invoiceNumber}-invoice.html`;
      link.click();
      URL.revokeObjectURL(link.href);
      toast({
        variant: "success",
        title: "Invoice downloaded",
        description: "A printable invoice file was saved to your device.",
      });
    } catch {
      toast({ variant: "error", title: "Download failed", description: "Please try again." });
    }
  };
  return (
    <>
      <PageMeta title={`Invoice ${bill.invoiceNumber}`} description="Professional printable customer invoice." />
      <div className="no-print mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold">Invoice generated</h1>
          <p className="text-sm text-muted-foreground">
            {bill.invoiceNumber} was saved and inventory updated. Choose your installed billing printer in the print
            window.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button className="bg-card text-foreground ring-1 ring-border hover:bg-muted" onClick={print}>
            <Printer size={17} />
            Print receipt now
          </Button>
          <Button className="bg-card text-foreground ring-1 ring-border hover:bg-muted" onClick={download}>
            <FileText size={17} />
            Download invoice
          </Button>
          <Button onClick={onNew}>
            <Plus size={17} />
            New bill
          </Button>
        </div>
      </div>
      <article
        id="invoice-print"
        className={cn(
          "invoice-document receipt-print mx-auto max-w-3xl rounded-lg border bg-card p-6 text-card-foreground shadow-sm sm:p-10",
          store.shop.receiptPaperSize === "58mm" ? "receipt-58" : "receipt-80",
        )}
      >
        <header className="flex justify-between gap-6 border-b pb-6">
          <div className="flex gap-3">
            {store.shop.logo ? (
              <img
                src={store.shop.logo}
                alt={`${store.shop.shopName} logo`}
                width="54"
                height="54"
                className="h-14 w-14 rounded-md object-cover"
              />
            ) : (
              <div className="grid h-14 w-14 place-items-center rounded-md bg-primary text-primary-foreground">
                <ShoppingBag size={26} />
              </div>
            )}
            <div>
              <h2 className="text-xl font-bold">{store.shop.shopName}</h2>
              <p className="mt-1 max-w-xs whitespace-pre-line text-sm text-muted-foreground">{store.shop.address}</p>
              <p className="text-sm text-muted-foreground">{store.shop.mobile}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xl font-bold">INVOICE</p>
            <p className="mt-1 font-semibold text-primary">{bill.invoiceNumber}</p>
            <p className="mt-1 text-sm text-muted-foreground">{formatDateTime(bill.date)}</p>
          </div>
        </header>
        <section className="flex justify-between gap-5 py-6">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">Billed to</h3>
            <p className="mt-2 font-semibold">{bill.customerName || "Walk-in customer"}</p>
            {bill.customerMobile && <p className="text-sm text-muted-foreground">{bill.customerMobile}</p>}
          </div>
          <div className="text-right">
            <h3 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">Payment</h3>
            <p className="mt-2 font-semibold">{bill.paymentMethod}</p>
            {bill.paymentMethod !== "Credit / Due" && (
              <p className="text-sm text-muted-foreground">
                Received {formatCurrency(bill.amountReceived, store.shop.currency)}
              </p>
            )}
          </div>
        </section>
        <table className="w-full text-sm">
          <thead className="bg-muted text-left text-muted-foreground">
            <tr>
              <th className="px-3 py-3 font-medium">Product</th>
              <th className="px-3 py-3 text-right font-medium">Qty</th>
              <th className="px-3 py-3 text-right font-medium">Price</th>
              <th className="px-3 py-3 text-right font-medium">Discount amount</th>
              <th className="px-3 py-3 text-right font-medium">Total</th>
            </tr>
          </thead>
          <tbody>
            {bill.items.map((item) => {
              const itemSubtotal = item.price * item.quantity;
              const itemDiscount = Math.min(
                item.discountScope === "line" ? itemSubtotal : item.price,
                Math.max(0, Number.isFinite(item.discount) ? item.discount : 0),
              );
              const totalDiscount = item.discountScope === "line" ? itemDiscount : itemDiscount * item.quantity;
              return (
                <tr key={item.productId} className="border-b">
                  <td className="px-3 py-3 font-medium">{item.name}</td>
                  <td className="px-3 py-3 text-right">
                    {formatProductQuantity(item.quantity, store.products.find((product) => product.id === item.productId)?.unit || "piece")}
                  </td>
                  <td className="px-3 py-3 text-right">{formatCurrency(item.price, store.shop.currency)}</td>
                  <td className="px-3 py-3 text-right">{formatCurrency(totalDiscount, store.shop.currency)}</td>
                  <td className="px-3 py-3 text-right font-semibold">
                    {formatCurrency(itemSubtotal - totalDiscount, store.shop.currency)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <section className="ml-auto mt-6 max-w-xs space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Subtotal</span>
            <span>{formatCurrency(bill.subtotal, store.shop.currency)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Discount</span>
            <span>-{formatCurrency(bill.discount, store.shop.currency)}</span>
          </div>
          <div className="flex justify-between border-t pt-2 text-lg font-bold">
            <span>Grand total</span>
            <span>{formatCurrency(bill.total, store.shop.currency)}</span>
          </div>
        </section>
        <footer className="mt-8 border-t pt-6 text-center">
          <p className="font-semibold">Thank you! Visit Again</p>
          <p className="mt-1 text-xs text-muted-foreground">Generated by ShopMate POS</p>
        </footer>
      </article>
    </>
  );
}

function CustomersPage({ store, commit }: StoreApi) {
  const { toast } = useToast();
  const [query, setQuery] = useState("");
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", mobile: "", address: "" });
  const [selected, setSelected] = useState<Customer | null>(null);
  const customers = store.customers.filter((customer) =>
    `${customer.name} ${customer.mobile}`.toLowerCase().includes(query.toLowerCase()),
  );
  const add = async (event: FormEvent) => {
    event.preventDefault();
    if (!form.name.trim()) return;
    try {
      const customer = { id: crypto.randomUUID(), ...form, totalPurchases: 0, due: 0 };
      await commit((current) => ({ ...current, customers: [customer, ...current.customers] }));
      setAdding(false);
      setForm({ name: "", mobile: "", address: "" });
      toast({
        variant: "success",
        title: "Customer added successfully",
        description: `${customer.name} is ready to use on bills.`,
      });
    } catch {
      toast({ variant: "error", title: "Could not add customer", description: "Please try again." });
    }
  };
  return (
    <>
      <PageMeta title="Customers" description="Manage customer contacts, purchase history, and outstanding balances." />
      <PageHead
        title="Customers"
        text="Keep customer details and outstanding dues in one place."
        action={
          <Button onClick={() => setAdding(true)}>
            <Plus size={17} />
            Add customer
          </Button>
        }
      />
      <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
        <div className="border-b p-4">
          <div className="relative max-w-md">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              aria-label="Search customers"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="pl-10"
              placeholder="Search customer name or mobile"
            />
          </div>
        </div>
        {customers.length ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[650px] text-sm">
              <thead className="bg-muted text-left text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Customer</th>
                  <th className="px-4 py-3 font-medium">Mobile</th>
                  <th className="px-4 py-3 text-right font-medium">Total purchases</th>
                  <th className="px-4 py-3 text-right font-medium">Outstanding due</th>
                  <th className="px-4 py-3 text-right font-medium">Details</th>
                </tr>
              </thead>
              <tbody>
                {customers.map((customer) => (
                  <tr key={customer.id} className="border-t hover:bg-muted/50">
                    <td className="px-4 py-3 font-semibold">{customer.name}</td>
                    <td className="px-4 py-3">{customer.mobile || "—"}</td>
                    <td className="px-4 py-3 text-right">
                      {formatCurrency(customer.totalPurchases, store.shop.currency)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className={customer.due > 0 ? "font-semibold text-destructive" : ""}>
                        {formatCurrency(customer.due, store.shop.currency)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Button
                        className="min-h-8 bg-card px-2 text-foreground ring-1 ring-border hover:bg-muted"
                        onClick={() => setSelected(customer)}
                      >
                        View history
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={Users}
            title={query ? "No customers found" : "No customers yet"}
            text={
              query
                ? "Try a different name or mobile number."
                : "Customers are added automatically during billing, or you can add one now."
            }
            action={
              <Button onClick={() => (query ? setQuery("") : setAdding(true))}>
                {query ? "Clear search" : "Add customer"}
              </Button>
            }
          />
        )}
      </div>
      <Modal open={adding} title="Add customer" onClose={() => setAdding(false)}>
        <form onSubmit={add} className="space-y-4">
          <Field label="Customer name *" id="customer-name">
            <Input
              id="customer-name"
              value={form.name}
              onChange={(event) => setForm({ ...form, name: event.target.value })}
              required
            />
          </Field>
          <Field label="Mobile number" id="customer-mobile">
            <Input
              id="customer-mobile"
              value={form.mobile}
              onChange={(event) => setForm({ ...form, mobile: event.target.value })}
            />
          </Field>
          <Field label="Address" id="customer-address">
            <Input
              id="customer-address"
              value={form.address}
              onChange={(event) => setForm({ ...form, address: event.target.value })}
            />
          </Field>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
              onClick={() => setAdding(false)}
            >
              Cancel
            </Button>
            <Button type="submit">Save customer</Button>
          </div>
        </form>
      </Modal>
      <Modal open={!!selected} title="Customer history" onClose={() => setSelected(null)}>
        {selected && (
          <div>
            <div className="grid grid-cols-2 gap-3 rounded-md bg-muted p-4 text-sm">
              <div>
                <p className="text-muted-foreground">Total purchases</p>
                <p className="mt-1 text-lg font-bold">{formatCurrency(selected.totalPurchases, store.shop.currency)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Outstanding due</p>
                <p className="mt-1 text-lg font-bold text-destructive">
                  {formatCurrency(selected.due, store.shop.currency)}
                </p>
              </div>
            </div>
            <h3 className="mt-5 font-bold">Previous bills</h3>
            <div className="mt-3 space-y-2">
              {store.bills.filter(
                (bill) =>
                  bill.customerId === selected.id || (selected.mobile && bill.customerMobile === selected.mobile),
              ).length ? (
                store.bills
                  .filter(
                    (bill) =>
                      bill.customerId === selected.id || (selected.mobile && bill.customerMobile === selected.mobile),
                  )
                  .map((bill) => (
                    <div key={bill.id} className="flex justify-between rounded-md border p-3 text-sm">
                      <div>
                        <p className="font-semibold">{bill.invoiceNumber}</p>
                        <p className="text-muted-foreground">
                          {formatDateTime(bill.date)} · {bill.paymentMethod}
                        </p>
                      </div>
                      <p className="font-bold">{formatCurrency(bill.total, store.shop.currency)}</p>
                    </div>
                  ))
              ) : (
                <p className="text-sm text-muted-foreground">No previous bills yet.</p>
              )}
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}

function BillsPage({ store }: { store: Store }) {
  const { toast } = useToast();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [viewing, setViewing] = useState<Bill | null>(null);
  const [printWhenOpened, setPrintWhenOpened] = useState(false);
  const print = () => {
    try {
      window.print();
    } catch {
      toast({ variant: "error", title: "Print could not open", description: "Please try your browser print command." });
    }
  };
  useEffect(() => {
    if (!viewing || !printWhenOpened) return;
    const frame = window.requestAnimationFrame(() => {
      print();
      setPrintWhenOpened(false);
    });
    return () => window.cancelAnimationFrame(frame);
  }, [viewing, printWhenOpened]);
  const day = new Date();
  const start = new Date(day);
  if (filter === "Today") start.setHours(0, 0, 0, 0);
  if (filter === "Yesterday") {
    start.setDate(day.getDate() - 1);
    start.setHours(0, 0, 0, 0);
  }
  if (filter === "This Week") start.setDate(day.getDate() - 7);
  if (filter === "This Month") start.setMonth(day.getMonth() - 1);
  const filtered = store.bills.filter(
    (bill) =>
      (filter === "All" || new Date(bill.date) >= start) &&
      `${bill.invoiceNumber} ${bill.customerName}`.toLowerCase().includes(query.toLowerCase()),
  );
  const download = (bill: Bill) => {
    try {
      const blob = new Blob([JSON.stringify(bill, null, 2)], { type: "application/json" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `${bill.invoiceNumber}.json`;
      link.click();
      URL.revokeObjectURL(link.href);
      toast({ variant: "success", title: "Bill download created", description: "Your bill record was downloaded." });
    } catch {
      toast({ variant: "error", title: "Download failed", description: "Please try again." });
    }
  };
  return (
    <>
      <PageMeta title="Bills" description="Search, review, print, and download all completed sales invoices." />
      <PageHead title="Bills &amp; sales history" text="Search invoices and review completed sales." />
      <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
        <div className="flex flex-col gap-3 border-b p-4 md:flex-row md:items-center md:justify-between">
          <div className="relative max-w-md flex-1">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              aria-label="Search bills"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="pl-10"
              placeholder="Invoice number or customer"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {["All", "Today", "Yesterday", "This Week", "This Month"].map((item) => (
              <button
                type="button"
                key={item}
                onClick={() => setFilter(item)}
                className={cn(
                  "rounded-md px-3 py-2 text-sm font-medium hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  filter === item && "bg-accent text-primary",
                )}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
        {filtered.length ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[800px] text-sm">
              <thead className="bg-muted text-left text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Invoice</th>
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3 font-medium">Customer</th>
                  <th className="px-4 py-3 text-right font-medium">Amount</th>
                  <th className="px-4 py-3 font-medium">Payment</th>
                  <th className="px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((bill) => (
                  <tr key={bill.id} className="border-t hover:bg-muted/50">
                    <td className="px-4 py-3 font-semibold">{bill.invoiceNumber}</td>
                    <td className="px-4 py-3">{formatDateTime(bill.date)}</td>
                    <td className="px-4 py-3">{bill.customerName || "Walk-in customer"}</td>
                    <td className="px-4 py-3 text-right font-semibold">
                      {formatCurrency(bill.total, store.shop.currency)}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge>{bill.paymentMethod}</StatusBadge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <Button
                          className="min-h-8 bg-card px-2 text-foreground ring-1 ring-border hover:bg-muted"
                          onClick={() => setViewing(bill)}
                        >
                          View bill
                        </Button>
                        <button
                          type="button"
                          onClick={() => {
                            setViewing(bill);
                            setPrintWhenOpened(true);
                          }}
                          aria-label={`Print ${bill.invoiceNumber}`}
                          title="Print bill"
                          className="rounded-md p-2 hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        >
                          <Printer size={17} />
                        </button>
                        <button
                          type="button"
                          onClick={() => download(bill)}
                          aria-label={`Download ${bill.invoiceNumber}`}
                          className="rounded-md p-2 hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        >
                          <FileText size={17} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={ClipboardList}
            title="No bills match your search"
            text="Try changing the date filter or search words."
            action={
              <Button
                onClick={() => {
                  setFilter("All");
                  setQuery("");
                }}
              >
                Clear filters
              </Button>
            }
          />
        )}
      </div>
      <Modal open={!!viewing} title={viewing?.invoiceNumber || "Bill"} onClose={() => setViewing(null)}>
        {viewing && (
          <div
            id="invoice-print"
            className={cn(
              "invoice-document receipt-print space-y-4",
              store.shop.receiptPaperSize === "58mm" ? "receipt-58" : "receipt-80",
            )}
          >
            <div className="flex justify-between rounded-md bg-muted p-4">
              <div>
                <p className="font-semibold">{store.shop.shopName}</p>
                <p className="text-sm text-muted-foreground">
                  {viewing.customerName || "Walk-in customer"} · {formatDateTime(viewing.date)}
                </p>
              </div>
              <p className="font-bold">{viewing.invoiceNumber}</p>
            </div>
            {viewing.items.map((item) => {
              const itemSubtotal = item.price * item.quantity;
              const itemDiscount = Math.min(
                item.discountScope === "line" ? itemSubtotal : item.price,
                Math.max(0, Number.isFinite(item.discount) ? item.discount : 0),
              );
              const totalDiscount = item.discountScope === "line" ? itemDiscount : itemDiscount * item.quantity;
              return (
                <div key={item.productId} className="flex justify-between border-b pb-2 text-sm">
                  <span>
                    {item.name} × {formatProductQuantity(item.quantity, store.products.find((product) => product.id === item.productId)?.unit || "piece")}
                  </span>
                  <span>{formatCurrency(itemSubtotal - totalDiscount, store.shop.currency)}</span>
                </div>
              );
            })}
            <div className="flex justify-between text-sm font-bold">
              <span>Payment · {viewing.paymentMethod}</span>
              <span>{formatCurrency(viewing.total, store.shop.currency)}</span>
            </div>
            <p className="text-center text-sm font-semibold">Thank you! Visit Again</p>
            <div className="no-print border-t pt-4">
              <p className="mb-3 text-xs text-muted-foreground">
                Your browser will open its print window. Choose your installed billing printer and use the saved{" "}
                {store.shop.receiptPaperSize} paper size.
              </p>
              <Button className="w-full" onClick={print}>
                <Printer size={17} />
                Print receipt now
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}

function ReportsPage({ store }: { store: Store }) {
  const sales = store.bills.reduce((sum, bill) => sum + bill.total, 0);
  const profit = store.bills.reduce(
    (sum, bill) =>
      sum +
      bill.items.reduce((lineSum, item) => {
        const lineSubtotal = item.price * item.quantity;
        const lineDiscount = Math.min(
          item.discountScope === "line" ? lineSubtotal : item.price,
          Math.max(0, item.discount),
        );
        const totalDiscount = item.discountScope === "line" ? lineDiscount : lineDiscount * item.quantity;
        const purchaseCost =
          (store.products.find((product) => product.id === item.productId)?.purchasePrice || 0) * item.quantity;
        return lineSum + lineSubtotal - totalDiscount - purchaseCost;
      }, 0),
    0,
  );
  const paymentRows = (["Cash", "UPI", "Card", "Credit / Due"] as PaymentMethod[]).map((method) => ({
    method,
    total: store.bills.filter((bill) => bill.paymentMethod === method).reduce((sum, bill) => sum + bill.total, 0),
  }));
  const productRows = store.products
    .map((product) => ({
      product,
      quantity: store.bills
        .flatMap((bill) => bill.items)
        .filter((item) => item.productId === product.id)
        .reduce((sum, item) => sum + item.quantity, 0),
    }))
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);
  const due = store.customers.reduce((sum, customer) => sum + customer.due, 0);
  return (
    <>
      <PageMeta
        title="Reports"
        description="Review daily sales, product performance, profit, payments, and customer dues."
      />
      <PageHead title="Reports" text="Simple reports to understand your sales and inventory." />
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Total sales", value: sales },
          { label: "Estimated profit", value: profit },
          { label: "Discount given", value: store.bills.reduce((sum, bill) => sum + bill.discount, 0) },
          { label: "Outstanding due", value: due },
        ].map((card) => (
          <article key={card.label} className="rounded-lg border bg-card p-5 shadow-sm">
            <p className="text-sm text-muted-foreground">{card.label}</p>
            <p className="mt-3 text-2xl font-bold">{formatCurrency(card.value, store.shop.currency)}</p>
          </article>
        ))}
      </section>
      <section className="mt-6 grid gap-6 lg:grid-cols-2">
        <article className="rounded-lg border bg-card p-5 shadow-sm">
          <h2 className="font-bold">Payment method report</h2>
          <p className="mt-1 text-sm text-muted-foreground">Sales collected by payment type.</p>
          <div className="mt-5 space-y-4">
            {paymentRows.map((row) => (
              <div key={row.method}>
                <div className="mb-1 flex justify-between text-sm">
                  <span>{row.method}</span>
                  <span className="font-semibold">{formatCurrency(row.total, store.shop.currency)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{ width: `${sales ? (row.total / sales) * 100 : 0}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </article>
        <article className="rounded-lg border bg-card p-5 shadow-sm">
          <h2 className="font-bold">Product sales report</h2>
          <p className="mt-1 text-sm text-muted-foreground">Top-selling products by quantity.</p>
          {productRows.some((row) => row.quantity) ? (
            <div className="mt-4 space-y-3">
              {productRows.map((row) => (
                <div key={row.product.id} className="flex items-center justify-between rounded-md bg-muted/60 p-3">
                  <div>
                    <p className="font-semibold">{row.product.name}</p>
                    <p className="text-xs text-muted-foreground">{row.product.category}</p>
                  </div>
                  <span className="font-bold">{formatProductQuantity(row.quantity, row.product.unit)} sold</span>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={BarChart3}
              title="No sales data yet"
              text="Complete a bill to unlock product and sales reports."
            />
          )}
        </article>
      </section>
      <section className="mt-6 rounded-lg border bg-card p-5 shadow-sm">
        <h2 className="font-bold">Available reports</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            "Daily Sales Report",
            "Weekly Sales Report",
            "Monthly Sales Report",
            "Profit Report",
            "Payment Method Report",
            "Outstanding / Due Report",
            "Product Sales Report",
          ].map((name) => (
            <div key={name} className="rounded-md border p-3">
              <FileText size={18} className="text-primary" />
              <p className="mt-3 text-sm font-semibold">{name}</p>
              <p className="mt-1 text-xs text-muted-foreground">Current workspace data</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

function SettingsPage({ user, store, commit }: StoreApi & { user: GenMBUser }) {
  const { toast } = useToast();
  const [shop, setShop] = useState(store.shop);
  const [saved, setSaved] = useState(false);
  useEffect(() => setShop(store.shop), [store.shop]);
  const set = <K extends keyof Shop>(key: K, value: Shop[K]) => {
    setSaved(false);
    setShop((current) => ({ ...current, [key]: value }));
  };
  const [saving, setSaving] = useState(false);
  const [resetPending, setResetPending] = useState(false);
  const sendPasswordReset = async () => {
    setResetPending(true);
    try {
      await window.genmb.auth.requestPasswordReset(user.email);
      toast({
        variant: "info",
        title: "Password reset email sent",
        description: `Check ${user.email} for secure instructions.`,
      });
    } catch (error: unknown) {
      toast({
        variant: "error",
        title: "Could not send reset email",
        description: error instanceof Error ? error.message : "Please try again.",
      });
    } finally {
      setResetPending(false);
    }
  };
  const save = async (event: FormEvent) => {
    event.preventDefault();
    setSaving(true);
    try {
      await commit((current) => ({ ...current, shop }));
      setSaved(true);
      toast({
        variant: "success",
        title: "Settings saved",
        description: "Your billing and inventory settings are updated.",
      });
    } catch {
      toast({ variant: "error", title: "Could not save settings", description: "Please try again." });
    } finally {
      setSaving(false);
    }
  };
  const resetStarter = async () => {
    try {
      await commit((current) => ({
        ...current,
        products: current.products.length ? current.products : starterProducts,
      }));
      toast({
        variant: "info",
        title: "Starter products restored",
        description: "Sample inventory is available to help you begin.",
      });
    } catch {
      toast({ variant: "error", title: "Could not restore products", description: "Please try again." });
    }
  };
  return (
    <>
      <PageMeta title="Settings" description="Update shop details and configure billing and inventory preferences." />
      <PageHead title="Settings" text="Manage shop information, billing defaults, and inventory rules." />
      <form onSubmit={save} className="space-y-6">
        <section className="rounded-lg border bg-card p-5 shadow-sm">
          <h2 className="text-lg font-bold">Shop settings</h2>
          <p className="mt-1 text-sm text-muted-foreground">Shown on every invoice and receipt.</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <Field label="Shop name" id="settings-shop">
              <Input
                id="settings-shop"
                value={shop.shopName}
                onChange={(event) => set("shopName", event.target.value)}
                required
              />
            </Field>
            <Field label="Owner name" id="settings-owner">
              <Input
                id="settings-owner"
                value={shop.ownerName}
                onChange={(event) => set("ownerName", event.target.value)}
              />
            </Field>
            <Field label="Phone" id="settings-phone">
              <Input id="settings-phone" value={shop.mobile} onChange={(event) => set("mobile", event.target.value)} />
            </Field>
            <Field label="Email" id="settings-email">
              <Input
                id="settings-email"
                type="email"
                value={shop.email}
                onChange={(event) => set("email", event.target.value)}
              />
            </Field>
            <Field label="Address" id="settings-address">
              <Input
                id="settings-address"
                value={shop.address}
                onChange={(event) => set("address", event.target.value)}
              />
            </Field>
            <Field label="Website & invoice logo" id="settings-logo">
              <Input
                id="settings-logo"
                type="file"
                accept="image/*"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => set("logo", String(reader.result));
                  reader.readAsDataURL(file);
                }}
              />
            </Field>
          </div>
          {shop.logo && (
            <div className="mt-4 flex items-center gap-3 rounded-md border bg-muted/40 p-3">
              <img
                src={shop.logo}
                alt={`${shop.shopName || "Shop"} logo preview`}
                className="h-12 w-12 rounded-md object-cover"
                onError={(event) => {
                  event.currentTarget.style.display = "none";
                }}
              />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">Current shop logo</p>
                <p className="text-xs text-muted-foreground">
                  This logo is shown in the website navigation, billing screen, invoices, and receipts.
                </p>
              </div>
              <Button
                type="button"
                className="min-h-9 bg-card px-3 text-foreground ring-1 ring-border hover:bg-muted"
                onClick={() => set("logo", "")}
              >
                Remove logo
              </Button>
            </div>
          )}
        </section>
        <section className="rounded-lg border bg-card p-5 shadow-sm">
          <h2 className="text-lg font-bold">Billing &amp; receipt settings</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Select the paper width that matches your installed billing printer. The browser print window lets you choose
            that printer.
          </p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Invoice prefix" id="settings-prefix">
              <Input
                id="settings-prefix"
                value={shop.invoicePrefix}
                onChange={(event) => set("invoicePrefix", event.target.value)}
              />
            </Field>
            <Field label="Next invoice number" id="settings-number">
              <Input
                id="settings-number"
                type="number"
                min="1"
                value={shop.nextInvoiceNumber}
                onChange={(event) => set("nextInvoiceNumber", Number(event.target.value))}
              />
            </Field>
            <Field label="Default line discount amount" id="settings-discount">
              <Input
                id="settings-discount"
                type="number"
                min="0"
                step="0.01"
                value={shop.defaultDiscount}
                onChange={(event) => set("defaultDiscount", Number(event.target.value))}
              />
            </Field>
            <Field label="Billing printer paper width" id="settings-paper">
              <select
                id="settings-paper"
                value={shop.receiptPaperSize}
                onChange={(event) => set("receiptPaperSize", event.target.value as Shop["receiptPaperSize"])}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="80mm">80 mm thermal receipt</option>
                <option value="58mm">58 mm thermal receipt</option>
              </select>
            </Field>
          </div>
          <label className="mt-5 flex cursor-pointer items-center justify-between rounded-md border p-4">
            <span>
              <span className="block font-semibold">Open print window after every completed bill</span>
              <span className="text-sm text-muted-foreground">
                Turn this on for a faster thermal-printer workflow. You can still choose the printer in the browser
                print window.
              </span>
            </span>
            <input
              type="checkbox"
              checked={shop.autoPrintReceipt}
              onChange={(event) => set("autoPrintReceipt", event.target.checked)}
              className="h-4 w-4 accent-[var(--primary)]"
            />
          </label>
        </section>
        <section className="rounded-lg border bg-card p-5 shadow-sm">
          <h2 className="text-lg font-bold">Inventory settings</h2>
          <div className="mt-4 space-y-3">
            <label className="flex cursor-pointer items-center justify-between rounded-md border p-4">
              <span>
                <span className="block font-semibold">Low stock alerts</span>
                <span className="text-sm text-muted-foreground">
                  Show warnings when stock reaches its minimum level.
                </span>
              </span>
              <input
                type="checkbox"
                checked={shop.lowStockAlert}
                onChange={(event) => set("lowStockAlert", event.target.checked)}
                className="h-4 w-4 accent-[var(--primary)]"
              />
            </label>
            <label className="flex cursor-pointer items-center justify-between rounded-md border p-4">
              <span>
                <span className="block font-semibold">Allow negative stock</span>
                <span className="text-sm text-muted-foreground">
                  Permit sales even when available stock is not enough.
                </span>
              </span>
              <input
                type="checkbox"
                checked={shop.allowNegativeStock}
                onChange={(event) => set("allowNegativeStock", event.target.checked)}
                className="h-4 w-4 accent-[var(--primary)]"
              />
            </label>
          </div>
        </section>
        <section className="rounded-lg border bg-card p-5 shadow-sm">
          <h2 className="text-lg font-bold">User settings</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Password changes and sign-in methods are managed securely through your account provider.
          </p>
          <Button
            type="button"
            className="mt-4 bg-card text-foreground ring-1 ring-border hover:bg-muted"
            onClick={() => void sendPasswordReset()}
            loading={resetPending}
          >
            Send password reset email
          </Button>
        </section>
        <div className="flex flex-wrap justify-end gap-2">
          <Button
            type="button"
            className="bg-card text-foreground ring-1 ring-border hover:bg-muted"
            onClick={resetStarter}
          >
            Restore starter products
          </Button>
          <Button type="submit" loading={saving}>
            Save settings
          </Button>
        </div>
        {saved && <p className="text-right text-sm text-primary">All settings are saved.</p>}
      </form>
    </>
  );
}
